import React, { useEffect, useMemo, useState, useCallback } from "react";
import SymptomForm from "./components/SymptomForm.jsx";
import MappingResult from "./components/MappingResult.jsx";
import HospitalList from "./components/HospitalList.jsx";
import NetworkMap from "./components/NetworkMap.jsx";
import StaffPanel from "./components/StaffPanel.jsx";
import { getHospitals, postRoute } from "./api";

const DEFAULT_LAT = 13.06;
const DEFAULT_LNG = 80.25;

const navItems = [
  ["01", "Emergency Routing", "intake"],
  ["02", "Live Network", "network"],
  ["03", "Hospitals", "routing-results"],
];

const heroNodes = [
  ["CITY GENERAL", "ready", "node-a"],
  ["APOLLO EMERGENCY", "ready", "node-b"],
  ["RIVERSIDE TRAUMA", "ready", "node-c"],
  ["ANNA NAGAR", "limited", "node-d"],
  ["MARINA HEART", "limited", "node-e"],
  ["LIGHTHOUSE STROKE", "ready", "node-f"],
  ["VELACHERY RURAL", "critical", "node-g"],
  ["TAMBARAM", "ready", "node-h"],
];

export default function App() {
  const [hospitals, setHospitals] = useState(null);
  const [lat, setLat] = useState(DEFAULT_LAT);
  const [lng, setLng] = useState(DEFAULT_LNG);
  const [routeResult, setRouteResult] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const [lastSync, setLastSync] = useState(null);

  const refreshHospitals = useCallback(() => {
    getHospitals()
      .then((data) => {
        setHospitals(data.hospitals);
        setLastSync(new Date());
      })
      .catch(() => {});
  }, []);

  useEffect(() => {
    refreshHospitals();
    const id = setInterval(refreshHospitals, 6000);
    return () => clearInterval(id);
  }, [refreshHospitals]);

  async function handleSubmit(text) {
    setLoading(true);
    setError(null);
    try {
      const data = await postRoute({ text, lat, lng });
      setRouteResult(data);
      setTimeout(() => document.getElementById("routing-results")?.scrollIntoView({ behavior: "smooth", block: "start" }), 80);
    } catch (e) {
      setError(e.message);
      setRouteResult(null);
    } finally {
      setLoading(false);
    }
  }

  const recommendedId = routeResult?.results?.recommended?.hospital?.id || null;
  const networkStats = useMemo(() => {
    if (!hospitals?.length) return { ready: 0, limited: 0, wait: "—" };
    const ready = hospitals.filter((h) => Object.values(h.capabilities).every(Boolean)).length;
    const limited = hospitals.length - ready;
    const average = Math.round(hospitals.reduce((sum, h) => sum + h.erWaitMinutes, 0) / hospitals.length);
    return { ready, limited, wait: average };
  }, [hospitals]);

  const scrollTo = (id) => document.getElementById(id)?.scrollIntoView({ behavior: "smooth", block: "start" });

  return (
    <div className="app-shell">
      <header className="app-header">
        <div className="header-grid" />
        <div className="header-inner">
          <button className="brand-lockup" onClick={() => window.scrollTo({ top: 0, behavior: "smooth" })} aria-label="Go to top">
            <span className="brand-mark"><span>+</span><i /></span>
            <span className="brand-copy">
              <span className="eyebrow">EMERGENCY ROUTING INTELLIGENCE</span>
              <strong>CarePath</strong>
              <small>The “Golden Hour” Trauma &amp; Stroke Router</small>
            </span>
          </button>

          <nav className="top-nav" aria-label="CarePath sections">
            {navItems.map(([num, label, id]) => <button key={id} onClick={() => scrollTo(id)}><span>{num}</span>{label}</button>)}
          </nav>

          <div className="header-actions">
            <div className="live-status">
              <span className="live-dot" />
              <div><b>{hospitals?.length || 8} FACILITIES ONLINE</b><small>{lastSync ? "network synced just now" : "connecting…"}</small></div>
            </div>
            <button className="header-cta" onClick={() => scrollTo("intake")}><span>⌁</span> START EMERGENCY ROUTING <b>→</b></button>
          </div>
        </div>
      </header>

      <main className="page">
        <section className="hero-banner">
          <div className="hero-copy">
            <div className="hero-kicker"><span>●</span> NON-DIAGNOSTIC <i>•</i> LIVE CAPABILITY ROUTING</div>
            <h1>Route the<br />emergency.<br /><em>Not just the<br />ambulance.</em></h1>
            <p>CarePath turns plain-language urgency into live hospital capability requirements — then ranks facilities by the fastest realistic path to treatment.</p>
            <div className="hero-actions">
              <button className="hero-primary" onClick={() => scrollTo("intake")}><span>START EMERGENCY ROUTING</span><b>→</b></button>
              <button className="hero-secondary" onClick={() => scrollTo("how-it-works")}>SEE HOW IT WORKS</button>
            </div>
            <div className="hero-proof"><span>ⓘ</span> Simulated demo network <i>•</i> No patient data stored <i>•</i> Non-diagnostic by design</div>
          </div>

          <div className="hero-visual" aria-hidden="true">
            <div className="visual-grid" />
            <div className="hero-halo halo-one" /><div className="hero-halo halo-two" />
            <div className="orbit orbit-a" /><div className="orbit orbit-b" />
            <svg className="hero-connections" viewBox="0 0 680 520" preserveAspectRatio="none">
              {heroNodes.map(([, , cls], i) => <line key={cls} className={`hero-line ${i === 0 ? "bright" : ""}`} x1="340" y1="258" x2={[[340,90],[475,128],[545,220],[548,340],[425,405],[245,405],[125,320],[145,190]][i][0]} y2={[[340,90],[475,128],[545,220],[548,340],[425,405],[245,405],[125,320],[145,190]][i][1]} />)}
            </svg>
            <div className="visual-core"><span>+</span><small>CAREPATH CORE</small></div>
            {heroNodes.map(([name, status, cls]) => <div key={name} className={`hero-node ${cls}`}><span className={`node-dot ${status}`} /><label>{name}</label></div>)}
            <div className="floating-card fc-neuro"><span className="mini-dot green" /><div><b>NEUROLOGIST</b><small>AVAILABLE</small></div></div>
            <div className="floating-card fc-ct"><span className="mini-dot green" /><div><b>CT / MRI</b><small>ONLINE</small></div></div>
            <div className="floating-card fc-er"><span className="mini-dot cyan" /><div><b>ER LOAD</b><small>LOW</small></div></div>
            <div className="floating-card fc-trauma"><span className="mini-dot amber" /><div><b>TRAUMA TEAM</b><small>READY</small></div></div>
          </div>
        </section>

        <section className="metric-strip" aria-label="Network summary">
          <div className="metric"><div className="metric-top"><span>FACILITIES MONITORED</span><b>♙</b></div><strong>{hospitals?.length || "—"}</strong><small>LIVE NETWORK</small></div>
          <div className="metric"><div className="metric-top"><span>FULLY OPERATIONAL</span><b>⌁</b></div><strong>{hospitals ? `${networkStats.ready}/${hospitals.length}` : "—"}</strong><small>CAPABILITY READY</small></div>
          <div className="metric"><div className="metric-top"><span>AVERAGE ER WAIT</span><b>◷</b></div><strong>{networkStats.wait}{networkStats.wait !== "—" ? " min" : ""}</strong><small>LIVE INTAKE SIGNAL</small></div>
          <div className="metric"><div className="metric-top"><span>TIME-TO-TREATMENT</span><b>ϟ</b></div><strong>FASTEST</strong><small>PRIMARY OBJECTIVE</small></div>
        </section>

        <div className="section-divider"><span>LIVE EMERGENCY CONTROL ROOM</span><i /><small>SIMULATED NETWORK FEED · AUTO SYNC 6 SEC</small></div>

        <div className="layout">
          <aside className="left-column">
            <div id="intake"><SymptomForm onSubmit={handleSubmit} loading={loading} lat={lat} lng={lng} onLocationChange={(a, b) => { setLat(a); setLng(b); }} /></div>
            {error && <div className="error-box"><span className="error-icon">!</span><div><strong>Routing unavailable</strong><span>{error}</span></div></div>}
            <StaffPanel hospitals={hospitals} onUpdated={refreshHospitals} />
          </aside>

          <section className="right-column">
            <div id="network"><NetworkMap hospitals={hospitals} patient={{ lat, lng }} recommendedId={recommendedId} /></div>
            {routeResult ? <MappingResult mapped={routeResult.mapped} /> : (
              <div className="empty-state card">
                <div className="empty-orb"><div>02</div><span /><span /><span /></div>
                <div><span className="section-eyebrow">NEXT: INTENT → ROUTE</span><h2>Describe what is happening to activate the routing engine</h2><p>CarePath translates the description into facility requirements and compares every live hospital in the network.</p></div>
                <div className="empty-arrow">→</div>
              </div>
            )}
            {routeResult && <div id="routing-results"><HospitalList results={routeResult.results} requirements={routeResult.mapped.requirements} /></div>}
          </section>
        </div>

        <section className="how-section" id="how-it-works">
          <div className="how-intro"><span className="section-eyebrow">WHY CAREPATH</span><h2>Nearest is not<br /><em>always fastest.</em></h2><p>Distance alone can send an emergency to a hospital that cannot treat it immediately. CarePath fuses the signals that matter at the point of routing.</p></div>
          <div className="how-steps">
            <div className="how-step"><span>01</span><div><b>UNDERSTAND</b><p>Plain-language emergency description</p></div></div>
            <div className="connector" />
            <div className="how-step"><span>02</span><div><b>CHECK LIVE CAPABILITY</b><p>Equipment, specialists and ER load</p></div></div>
            <div className="connector" />
            <div className="how-step active"><span>03</span><div><b>ROUTE FOR TREATMENT</b><p>Transit + live ER wait = total time</p></div></div>
          </div>
        </section>
      </main>

      <footer className="footer"><span><b>CarePath</b> · non-diagnostic emergency routing prototype</span><span>Live capability status is simulated for demonstration</span></footer>
    </div>
  );
}
