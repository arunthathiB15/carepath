import React, { useState } from "react";

const EXAMPLES = [
  { label: "Stroke", icon: "◒", text: "sudden facial drooping, cannot lift right arm, slurred speech" },
  { label: "Trauma", icon: "✦", text: "car accident, heavy bleeding, unconscious after head injury" },
  { label: "Cardiac", icon: "♥", text: "crushing chest pain and shortness of breath" },
];

export default function SymptomForm({ onSubmit, loading, lat, lng, onLocationChange }) {
  const [text, setText] = useState("");
  function submit(e) { e.preventDefault(); if (text.trim()) onSubmit(text); }
  return (
    <div className="card intake-card">
      <div className="card-heading"><div><span className="step-number">01</span><div><span className="section-eyebrow">EMERGENCY INTAKE</span><h2>Describe the emergency</h2></div></div><span className="secure-badge">NON-DIAGNOSTIC</span></div>
      <p className="helper">Use everyday language. CarePath only maps the description to the <b>hospital resources</b> required — it does not diagnose.</p>
      <form onSubmit={submit}>
        <div className={`textarea-wrap ${text ? "filled" : ""}`}><textarea aria-label="Emergency description" placeholder="Tell us what is happening… e.g. sudden facial drooping, can't lift right arm, slurred speech" value={text} onChange={(e) => setText(e.target.value)} /><span className="textarea-hint">{text.length}/500</span></div>
        <div className="quick-label">Try a scenario</div>
        <div className="quick-fills">{EXAMPLES.map((ex) => <button type="button" key={ex.label} onClick={() => setText(ex.text)}><span>{ex.icon}</span>{ex.label}</button>)}</div>
        <div className="location-box"><div className="location-head"><span>⌖</span><div><b>Patient location</b><small>Sample Chennai coordinates · replace with live GPS in production</small></div></div><div className="field-row"><label>Latitude<input type="number" step="0.0001" value={lat} onChange={(e) => onLocationChange(Number(e.target.value), lng)} /></label><label>Longitude<input type="number" step="0.0001" value={lng} onChange={(e) => onLocationChange(lat, Number(e.target.value))} /></label></div></div>
        <button className="primary-btn" type="submit" disabled={loading || !text.trim()}><span>{loading ? "Analysing & routing…" : "Find fastest-to-treat hospital"}</span><b>→</b></button>
      </form>
    </div>
  );
}
