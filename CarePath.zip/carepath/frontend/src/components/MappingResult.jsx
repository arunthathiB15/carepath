import React from "react";

const LABELS = { ct: "CT / MRI ready", cathlab: "Cath lab ready", neurologist: "Neurologist", surgeon: "Trauma surgeon", bloodbank: "Blood bank", cardiologist: "Cardiologist" };

export default function MappingResult({ mapped }) {
  if (!mapped) return null;
  const reqKeys = Object.keys(mapped.requirements || {}).filter((k) => mapped.requirements[k]);
  return (
    <div className="card mapping-card">
      <div className="card-heading">
        <div><span className="step-number">02</span><div><span className="section-eyebrow">INTENT MAPPING</span><h2>Infrastructure requirements</h2></div></div>
        <span className={`urgency-badge ${mapped.urgency === "Critical" ? "critical" : "moderate"}`}><i />{mapped.urgency} urgency</span>
      </div>
      <div className="mapping-result">
        <div className="mapping-icon">↗</div>
        <div>
          <strong>{mapped.label}</strong>
          <p>CarePath translated the description into facility requirements — not a diagnosis.</p>
          <div className="chips">
            {reqKeys.length ? reqKeys.map((k) => <span className="chip" key={k}>✓ {LABELS[k] || k}</span>) : <span className="chip">✓ General emergency capacity</span>}
            {mapped.wantsCentre && <span className="chip">✓ {mapped.wantsCentre.replace("is", "")} centre</span>}
          </div>
          <div className="mapping-note">{mapped.note}</div>
        </div>
      </div>
    </div>
  );
}
