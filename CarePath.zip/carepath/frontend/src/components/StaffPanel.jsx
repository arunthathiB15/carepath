import React, { useEffect, useState } from "react";
import { patchHospitalStatus } from "../api";
const LABELS = { ct: "CT / MRI", cathlab: "Cath Lab", neurologist: "Neurologist", surgeon: "Trauma Surgeon", bloodbank: "Blood Bank", cardiologist: "Cardiologist" };
export default function StaffPanel({ hospitals, onUpdated }) {
  const [openId, setOpenId] = useState(null), [busy, setBusy] = useState(false);
  useEffect(() => { if (!openId && hospitals?.[0]) setOpenId(hospitals[0].id); }, [hospitals, openId]);
  async function toggleCap(hospitalId, capKey, current) { setBusy(true); try { await patchHospitalStatus(hospitalId, { capabilities: { [capKey]: !current } }); onUpdated(); } finally { setBusy(false); } }
  if (!hospitals) return null;
  const h = hospitals.find((x) => x.id === openId);
  return <div className="card staff-card"><div className="card-heading"><div><span className="section-eyebrow">HOSPITAL SIDE</span><h2>Manual status-ping</h2></div><span className="staff-badge">STAFF DEMO</span></div><p className="helper">For hospitals without EHR/IoT integration, staff can publish a 30-second live capability update.</p><select value={openId || ""} onChange={(e) => setOpenId(e.target.value)}>{hospitals.map((x) => <option key={x.id} value={x.id}>{x.name}</option>)}</select>{h && <><div className="staff-hospital"><div className="hospital-dot green" /><div><b>{h.name}</b><small>Last update by {h.updatedBy}</small></div><span className="status-pill">● Connected</span></div><div className="staff-controls">{Object.entries(h.capabilities).map(([key,val]) => <div className="staff-panel-row" key={key}><span><i className={val ? "status-on" : "status-off"} />{LABELS[key] || key}</span><button className={`toggle-btn ${val ? "on" : "off"}`} disabled={busy} onClick={() => toggleCap(h.id,key,val)}>{val ? "Active" : "Down"}</button></div>)}</div><div className="er-mini"><span>ER intake wait</span><b>{h.erWaitMinutes} min</b></div></>}</div>;
}
