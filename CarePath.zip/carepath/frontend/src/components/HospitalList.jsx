import React from "react";

const CAP_LABELS = { ct: "CT/MRI", cathlab: "Cath Lab", neurologist: "Neurologist", surgeon: "Surgeon", bloodbank: "Blood Bank", cardiologist: "Cardiologist" };

function HospitalCard({ entry, recommended, requirements }) {
  const { hospital, distanceKm, transitMinutes, erWaitMinutes, totalMinutes, eligible, missing } = entry;
  const relevantCaps = Object.keys(requirements || {}).filter((k) => requirements[k]);
  const capsToShow = relevantCaps.length ? relevantCaps : Object.keys(hospital.capabilities);
  return (
    <div className={`hospital-card ${recommended ? "recommended" : ""} ${!eligible ? "excluded" : ""}`}>
      {recommended && <span className="tag">★ FASTEST ELIGIBLE MATCH</span>}
      <div className="hospital-main">
        <div className="hospital-name"><span className={`hospital-dot ${recommended ? "green" : ""}`} /><div><h3>{hospital.name}</h3><small>{eligible ? "Meets the current live requirements" : "Missing one or more live requirements"}</small></div></div>
        {!eligible && <span className="badge critical">SKIPPED</span>}
      </div>
      <div className="metrics">
        <div><b>{distanceKm}<small> km</small></b><span>distance</span></div>
        <div><b>{transitMinutes}<small> min</small></b><span>transit</span></div>
        <div><b>{erWaitMinutes}<small> min</small></b><span>live ER wait</span></div>
        <div className="total"><b>{totalMinutes}<small> min</small></b><span>time to treatment</span></div>
      </div>
      <div className="caps">{capsToShow.map((k) => <span key={k} className={`cap-pill ${hospital.capabilities[k] ? "up" : "down"}`}><i />{CAP_LABELS[k] || k} <em>{hospital.capabilities[k] ? "Ready" : "Down"}</em></span>)}</div>
      {!eligible && missing.length > 0 && <div className="missing-note">Excluded · missing {missing.map((m) => CAP_LABELS[m] || m).join(", ")}</div>}
    </div>
  );
}

export default function HospitalList({ results, requirements }) {
  if (!results) return null;
  const { eligible, excluded } = results;
  return (
    <div className="card ranking-card">
      <div className="card-heading">
        <div><span className="step-number">03</span><div><span className="section-eyebrow">ROUTING DECISION</span><h2>Ranked hospitals</h2></div></div>
        <span className="objective-badge">TRANSIT + LIVE ER WAIT</span>
      </div>
      <div className="decision-banner"><span>⚡</span><div><b>Optimised for time-to-treatment</b><small>The green total is the estimated time before treatment can begin — not simply the shortest driving distance.</small></div></div>
      {eligible.length === 0 && <p className="muted">No hospital currently meets every requirement. CarePath would escalate to the nearest option with a live warning.</p>}
      {eligible.map((e, i) => <HospitalCard key={e.hospital.id} entry={e} recommended={i === 0} requirements={requirements} />)}
      {excluded.length > 0 && <><div className="section-title">Skipped despite proximity <span>{excluded.length}</span></div>{excluded.map((e) => <HospitalCard key={e.hospital.id} entry={e} requirements={requirements} />)}</>}
    </div>
  );
}
