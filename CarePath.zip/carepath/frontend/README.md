# CarePath Frontend

Enhanced SIH 2026 prototype UI for CarePath — the “Golden Hour” Trauma & Stroke Router.

## UI enhancements
- Preserved the original CarePath colour palette.
- Added a polished emergency-command-centre visual hierarchy and responsive layout.
- Added hero illustration/orbit graphic, metric strip, step indicators and status badges.
- Added animated live-network map with patient-to-hospital routing lines and recommended facility pulse.
- Added richer hospital ranking cards with time-to-treatment emphasis and capability states.
- Added animated empty state and micro-interactions on buttons/cards.
- Improved hospital staff manual status-ping panel.
- Preserved the existing API and routing behaviour.

## Run

```bash
npm install
npm run dev
```

The frontend expects the existing backend API under `/api`.


### Final UI palette
The final UI uses a deep emergency navy, electric blue/cyan interaction layer, clean cool-white surfaces, emerald operational status, and coral emergency accents. The routing logic and API integration are unchanged.
